package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView display;
    private double first = 0;
    private String op = "";
    private boolean fresh = true;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        display = findViewById(R.id.display);

        int[] nums = {R.id.b0,R.id.b1,R.id.b2,R.id.b3,R.id.b4,R.id.b5,R.id.b6,R.id.b7,R.id.b8,R.id.b9};
        for (int id : nums) findViewById(id).setOnClickListener(v -> number(((Button)v).getText().toString()));

        findViewById(R.id.bDot).setOnClickListener(v -> dot());
        findViewById(R.id.bAC).setOnClickListener(v -> clear());
        findViewById(R.id.bBack).setOnClickListener(v -> back());
        findViewById(R.id.bPlusMinus).setOnClickListener(v -> plusMinus());
        findViewById(R.id.bPercent).setOnClickListener(v -> percent());
        findViewById(R.id.bPlus).setOnClickListener(v -> operator("+"));
        findViewById(R.id.bMinus).setOnClickListener(v -> operator("-"));
        findViewById(R.id.bMultiply).setOnClickListener(v -> operator("*"));
        findViewById(R.id.bDivide).setOnClickListener(v -> operator("/"));
        findViewById(R.id.bEquals).setOnClickListener(v -> equals());
    }

    private void number(String n) {
        if (fresh || display.getText().toString().equals("0")) {
            display.setText(n); fresh = false;
        } else display.append(n);
    }
    private void dot() {
        if (fresh) { display.setText("0."); fresh = false; }
        else if (!display.getText().toString().contains(".")) display.append(".");
    }
    private void operator(String o) {
        first = value(); op = o; fresh = true;
    }
    private void equals() {
        if (op.isEmpty()) return;
        double second = value(), result;
        if (op.equals("+")) result = first + second;
        else if (op.equals("-")) result = first - second;
        else if (op.equals("*")) result = first * second;
        else {
            if (second == 0) { display.setText("Error"); op=""; fresh=true; return; }
            result = first / second;
        }
        display.setText(format(result)); op=""; fresh=true;
    }
    private double value() {
        try { return Double.parseDouble(display.getText().toString()); }
        catch (Exception e) { return 0; }
    }
    private String format(double x) {
        if (x == (long)x) return Long.toString((long)x);
        return Double.toString(x);
    }
    private void clear() { display.setText("0"); first=0; op=""; fresh=true; }
    private void back() {
        String s=display.getText().toString();
        if (fresh || s.length()<=1 || s.equals("Error")) clear();
        else display.setText(s.substring(0,s.length()-1));
    }
    private void plusMinus() {
        if (display.getText().toString().equals("0") || display.getText().toString().equals("Error")) return;
        double x=value(); display.setText(format(-x));
    }
    private void percent() { display.setText(format(value()/100.0)); }
}
