# Simple Calculator

A simple Android calculator with +, −, ×, ÷, %, decimal, sign, backspace and clear.

## Build
Push this repository to GitHub and run the **Build APK** workflow under **Actions**. Download the `simple-calculator-apk` artifact.
